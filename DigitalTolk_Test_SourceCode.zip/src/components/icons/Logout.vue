<template>
	<svg
		width="20"
		version="1.1"
		id="Layer_1"
		xmlns="http://www.w3.org/2000/svg"
		xmlns:xlink="http://www.w3.org/1999/xlink"
		x="0px"
		y="0px"
		viewBox="0 0 24 24"
		style="enable-background: new 0 0 24 24"
		xml:space="preserve"
	>
		<path
			class="st0"
			d="M10.5,3h-5c-1.1,0-2,0.9-2,2v14c0,1.1,0.9,2,2,2h5 M20.5,12l-4-4 M20.5,12l-4,4 M20.5,12h-10"
		/>
	</svg>
</template>
