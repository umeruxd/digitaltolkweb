export const API_URL = 'https://todo-test.digitaltolk.com/api/';
