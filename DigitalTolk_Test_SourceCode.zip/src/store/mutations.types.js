export const UPDATE_ACCESS_TOKEN = 'updateAccessToken';
export const SET_LOCATION = 'setLocation';
export const SET_LOCATIONS = 'setLocations';
export const SET_LOCATION_FROM_STORAGE = 'setLocationFromStoragae';
export const SET_TOAST_DATA = 'setToastData';
export const SET_TASKS = 'setTasks';
